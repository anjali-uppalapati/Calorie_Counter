<?php
session_start();

if(isset($_SESSION['meal'])){
    extract($_SESSION['meal']);
    //echo $fname;
    $conn = mysqli_connect('localhost','root','','mealplan_db');
    
    $sql= mysqli_query($conn,"INSERT INTO info (height,gender,weight,activityLevel,age,goal,diet,carb,protein,fat)                             VALUES('$height','$gender','$weight','$activityLevel','$age','$goal','$diet','$carb','$protein','$fat')");

    if ($sql){
        unset($_SESSION['meal']);
        //echo "data succ recored";
    }
    
}
	 $conn = mysqli_connect('localhost','root','','mealplan_db');

        if ($conn->connect_error) {
          die( "Failed to connect to MySQL: " . $conn->connect_error);
        }

        $heightInfo ="SELECT height FROM info ORDER BY id DESC LIMIT 1";
        $genderInfo ="SELECT gender FROM info ORDER BY id DESC LIMIT 1";
        $weightInfo ="SELECT weight FROM info ORDER BY id DESC LIMIT 1";
        $activityLevelInfo ="SELECT activityLevel FROM info ORDER BY id DESC LIMIT 1";
        $ageInfo ="SELECT age FROM info ORDER BY id DESC LIMIT 1";
        $goalInfo ="SELECT goal FROM info ORDER BY id DESC LIMIT 1";
        $dietInfo ="SELECT diet FROM info ORDER BY id DESC LIMIT 1";
        $carbInfo ="SELECT carb FROM info ORDER BY id DESC LIMIT 1";
        $proteinInfo ="SELECT protein FROM info ORDER BY id DESC LIMIT 1";
        $fatInfo ="SELECT fat FROM info ORDER BY id DESC LIMIT 1";

        $resultHeight = $conn->query($heightInfo);
        $resultGender = $conn->query($genderInfo);
        $resultWeight = $conn->query($weightInfo);
        $resultActivityLevel = $conn->query($activityLevelInfo);
        $resultAge = $conn->query($ageInfo);
        $resultGoal = $conn->query($goalInfo);
        $resultDiet = $conn->query($dietInfo);
        $resultCarb = $conn->query($carbInfo);
        $resultProtein = $conn->query($proteinInfo);
        $resultFat = $conn->query($fatInfo);

        $conn->close();

        $rowHeight = mysqli_fetch_all($resultHeight, MYSQLI_ASSOC);
        $rowGender = mysqli_fetch_all($resultGender, MYSQLI_ASSOC);
        $rowWeight = mysqli_fetch_all($resultWeight, MYSQLI_ASSOC);
        $rowActivityLevel = mysqli_fetch_all($resultActivityLevel, MYSQLI_ASSOC);
        $rowAge = mysqli_fetch_all($resultAge, MYSQLI_ASSOC);
        $rowGoal = mysqli_fetch_all($resultGoal, MYSQLI_ASSOC);
        $rowDiet = mysqli_fetch_all($resultDiet, MYSQLI_ASSOC);
        $rowCarb = mysqli_fetch_all($resultCarb, MYSQLI_ASSOC);
        $rowProtein = mysqli_fetch_all($resultProtein, MYSQLI_ASSOC);
        $rowFat = mysqli_fetch_all($resultFat, MYSQLI_ASSOC);
        
        $height = array_column($rowHeight, "height");
        $gender = array_column($rowGender, "gender");
        $weight = array_column($rowWeight, "weight");
        $activityLevel = array_column($rowActivityLevel, "activityLevel");
        $age = array_column($rowAge, "age");
        $goal = array_column($rowGoal, "goal");
        $diet = array_column($rowDiet, "diet");
        $carb = array_column($rowCarb, "carb");
        $protein = array_column($rowProtein, "protein");
        $fat = array_column($rowFat, "fat");
        
        echo '<script> var height = ' . json_encode($height) . '; </script>';
        echo '<script> var gender = ' . json_encode($gender) . '; </script>';
        echo '<script> var weight = ' . json_encode($weight) . '; </script>';
        echo '<script> var activityLevel = ' . json_encode($activityLevel) . '; </script>';
        echo '<script> var age = ' . json_encode($age) . '; </script>';
        echo '<script> var goal = ' . json_encode($goal) . '; </script>';
        echo '<script> var diet = ' . json_encode($diet) . '; </script>';
        echo '<script> var carbDislike = ' . json_encode($carb) . '; </script>';
        echo '<script> var proteinDislike = ' . json_encode($protein) . '; </script>';
        echo '<script> var fatDislike = ' . json_encode($fat) . '; </script>';
//print_r($_SESSION['info']);

?>

<!DOCTYPE html>
<html>
    <head>  
        <meta charset="utf-8">
        <title>Meal Plan Generator</title>
        <link rel="stylesheet" href="mpStyleSheet.css">
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
        <script>
            function start(){
                window.alert(height);
                //window.alert(gender);
                //window.alert(weight);
                //window.alert(activityLevel);
               // window.alert(age);
               // window.alert(goal);
                //window.alert(diet);
                //window.alert(carbDislike);
               // window.alert(proteinDislike);
               // window.alert(fatDislike);
		calcCalories();
                
            }

           function calcCalories(){
 		window.alert("CalcCalories called");
                var kg = weight * 2.2;
         	if (acticityLevel==1){
                   acticityLevel = 1.2;
                }
                else if (acticityLevel==2){
                   acticityLevel = 1.375;
                }
                else if (acticityLevel==3){
                    acticityLevel = 1.55;
                }
                else if (acticityLevel==4){
                    acticityLevel = 1.725;
                }
                else (acticityLevel==5){
                    acticityLevel = 1.9;
                }
                //if gender is 1 aka female
                //BMR = (10 × weight [kg]) + (6.25 × height [cm]) – (5 × age [years]) – 161
                if (gender==1){
                    bmr = (10 * kg)+(6.25 * height) - (5 * age) - 161;
                    tdee = bmr * activityLevel;
                    calories = tdee * goal;
                    document.getElementById("totalcalories").innerText =  "Total Calories " + calories
                }
                //if gender is 2 aka male
                //BMR = (10 × weight [kg]) + (6.25 × height [cm]) – (5 × age [years]) + 5
                else{
                    bmr = (10 * kg)+(6.25 * height) - (5 * age) + 5;
                    tdee = bmr * activityLevel;
                    calories = tdee * goal;
                    document.getElementById("totalcalories").innerText = "Total Calories " + calories;
                }
           }
            
            

            window.addEventListener("load",start,false);
        </script>
    </head>
    <body>
        <div class = "logo">
            <a href = "#"><img src = "http://127.0.0.1:61704/pic/nplogo.JPG"></a>
        </div>
        
        <nav>
        <ul>
            <li><a href = "mealplanP1.php">Calculator</a></li>
            <li><a href = "#">How it works</a></li>
        </ul>
        </nav>
        <div class="columnRL">
            <div class="rowR">
               <h1 style="margin-top: 60px;">Results</h1>
                <table id="macroTable">
            <thead>
                <tr>
                    <th>Carb</th>
                    <th>Protein</th>
                    <th>Fat</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="carb">#</td>
                    <td class ="protein">#</td>
                    <td class ="fat">#</td>
                </tr>
            </tbody>
        </table>
            </div>
            <div class="rowR">
                <div class = "weeklyLoss" id="weeklyLoss">lb weekly weight loss</div>
                <div class = "totalcalories" id="totalcalories">Total Calories #</div>
            </div>
            <div class="rowR">
                <div class="columnRL">
                <input id ="randomize" class="randbutton" type="button" value="Randomize" onClick="randomize()">
                </div>
                <div class="columnRR"> 
                    <p style = "font-size: 12pt; margin-top: 170px; text-align: right; margin-right: 20px;">Confused? Here is <a href="mpInfo.html" style="color:black;">how it works</a></p>
                </div>
            </div>
                
        </div>
        <div class="columnRR">
            <down>
            <a href="blankMp.pdf" download><p style = "font-size: 20pt; margin-bottom: 0px;">MealPlanMMDDYYYY.PDF</p></a>
            <embed src="blankMp.pdf" id ="pdf" type="application/pdf"/>
            </down>
        </div>
        
    </body>
</html>