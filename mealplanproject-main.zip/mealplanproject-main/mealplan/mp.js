alert("java is connected");
var carb = <?php echo $carb; ?>;
var prot = <?php echo $prot; ?>;
var fat = <?php echo $fat; ?>;//<?php echo json_encode($fat); ?>;

var goal= <?php echo $goal; ?>;
var calories;
var weeklyLoss;

var fatDislike = <?php echo $fat; ?>;;
var carbDislike = <?php echo $carb; ?>;
var protDislike = <?php echo $protein; ?>;

var weight = <?php echo $weight; ?>;
var age = <?php echo $age; ?>;
//false == male, true==female
var gender= <?php echo $gender; ?>;
/*Sedentary	Little to no exercise, such as a desk job with no additional physical activity	1.2
Lightly Active	Light exercise 1-2 days/week	1.375
Moderately Active	Moderate exercise 3-5 days/week	1.55
Very Active	Hard exercise 6-7 days/week	1.725
Extremely Active	Hard daily exercise and physical job or two times a day training	1.9
*/
var activityLevel = <?php echo $activityLevel; ?>;
//total daily energy expenditure
//TDEE = calories × activityLevel
var tdee;
//basmal metobolic rate
var bmr;
/*
Carbs: 4 calories per gram
40% of 2,000 calories = 800 calories of carbs per day
Total grams of carbs allowed per day = 800/4 = 200 grams
Proteins: 4 calories per gram
30% of 2,000 calories = 600 calories of protein per day
Total grams of protein allowed per day = 600/4 = 150 grams
Fats: 9 calories per gram
30% of 2,000 calories = 600 calories of protein per day
Total grams of fat allowed per day = 600/9 = 67 grams
*/

function start(){
    calcCalories();
    calcMacros();
    calWeeklyLoss();
    alert("java is connected");
}
function getAL(){
    if (acticityLevel==1){
       return 1.2;
    }
    else if (acticityLevel==2){
        return 1.375;
    }
     else if (acticityLevel==3){
        return 1.55;
    }
     else if (acticityLevel==4){
        return 1.725;
    }
     else if (acticityLevel==5){
        return 1.9;
    }
}

function calcCalories(){
    var kg = weight * 2.2;
    activityLevel= getAL();
    //if gender is 1 aka female
    //BMR = (10 × weight [kg]) + (6.25 × height [cm]) – (5 × age [years]) – 161
    if (gender==1){
        bmr = (10 * kg)+(6.25 * height) - (5 * age) - 161;
        tdee = bmr * activityLevel;
        calories = tdee * goal;
        document.getElementById("totalcalories").innerText = calories
    }
    //if gender is 2 aka male
    //BMR = (10 × weight [kg]) + (6.25 × height [cm]) – (5 × age [years]) + 5
    else{
        bmr = (10 * kg)+(6.25 * height) - (5 * age) + 5;
        tdee = bmr * activityLevel;
        calories = tdee * goal;
        document.getElementById("totalcalories").innerText = "Total Calories " + calories;
    }
    
    
}

function calcMacros(){
    carb = (calories * .3) / 4;
    prot = (calories * .4) / 4;
    fat = (calories * .3) / 9;
    
    var macroTable = document.getElementById('macroTable');
    macroTable.rows[1].cells[0].innerHTML = carb;
    macroTable.rows[1].cells[1].innerHTML = prot;
    macroTable.rows[1].cells[2].innerHTML = fat;
}

function calWeeklyLoss(){
    var deficit = tdee - calories;
    /*One lb of body fat contains about 3,500 calories. For a person to lose 1 lb of fat in a week,
    they would need a deficit of 3,500 calories, or 500 calories per day, */
    var weeklydef = deficit * 7;
    weeklyLoss = weeklydef / 3500;
    
    document.getElementById("weeklyLoss").innerText = weeklyLoss + " lb weekly weight loss";
}




window.addEventListener("load",start,false);