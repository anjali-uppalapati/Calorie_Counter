<?php
session_start();

if(isset($_SESSION['meal'])){
    extract($_SESSION['meal']);
    //echo $fname;
    $conn = mysqli_connect('localhost','root','','mealplan_db');
    
    $sql= mysqli_query($conn,"INSERT INTO info (height,gender,weight,activityLevel,age,goal,diet,carb,protein,fat)                             VALUES('$height','$gender','$weight','$activityLevel','$age','$goal','$diet','$carb','$protein','$fat')");

    if ($sql){
        unset($_SESSION['meal']);
        //echo "data succ recored";
    }
}

//print_r($_SESSION['info']);

?>

<!DOCTYPE html>
<html>
    <head>  
        <meta charset="utf-8">
        <title>Meal Plan Generator</title>
        <link rel="stylesheet" href="mpStyleSheet.css">
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
        <script>

            function start(){
                window.alert("called");
            }
            
            

            window.addEventListener("load",start,false);
        </script>
    </head>
    <body>
        <div class = "logo">
            <a href = "#"><img src = "http://127.0.0.1:61704/pic/nplogo.JPG"></a>
        </div>
        
        <nav>
        <ul>
            <li><a href = "mealplanP1.php">Calculator</a></li>
            <li><a href = "#">How it works</a></li>
        </ul>
        </nav>
        <div class="columnRL">
            <div class="rowR">
               <h1 style="margin-top: 60px;">Results</h1>
                <table id="macroTable">
            <thead>
                <tr>
                    <th>Carb</th>
                    <th>Protein</th>
                    <th>Fat</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="carb">#</td>
                    <td class ="protein">#</td>
                    <td class ="fat">#</td>
                </tr>
            </tbody>
        </table>
            </div>
            <div class="rowR">
                <div class = "weeklyLoss" id="weeklyLoss">lb weekly weight loss</div>
                <div class = "totalcalories" id="totalcalories">Total Calories #</div>
            </div>
            <div class="rowR">
                <div class="columnRL">
                <input id ="randomize" class="randbutton" type="button" value="Randomize" onClick="randomize()">
                </div>
                <div class="columnRR"> 
                    <p style = "font-size: 12pt; margin-top: 170px; text-align: right; margin-right: 20px;">Confused? Here is <a href="mpInfo.html" style="color:black;">how it works</a></p>
                </div>
            </div>
                
        </div>
        <div class="columnRR">
            <down>
            <a href="blankMp.pdf" download><p style = "font-size: 20pt; margin-bottom: 0px;">MealPlanMMDDYYYY.PDF</p></a>
            <embed src="blankMp.pdf" id ="pdf" type="application/pdf"/>
            </down>
        </div>
        
    </body>
</html>