<?php
session_start();
if (isset($_POST['next'])){
    
    foreach($_POST as $key => $value){
        $_SESSION['info'][$key]=$value;
    }
    
    $keys=array_keys($_SESSION['info']);
        
    if(in_array('next',$keys)){
        unset($_SESSION['info']['next']);
    }
       
    header("Location: mealplanP3.php");
    //print_r($_SESSION['info']);
}
?>
<!DOCTYPE html>
<html>
    <head>  
        <meta charset="utf-8">
        <title>Meal Plan Generator</title>
        <link rel="stylesheet" href="mpStyleSheet.css">
    </head>
    <body>
        
        <div class = "logo">
            <a href = "#"><img src = "http://localhost/mealplan/mplogo.jpg"></a>
        </div>
        <nav>
        <ul>
            <li><a href = "mealplanP1.php">Calculator</a></li>
            <li><a href = "#">How it works</a></li>
        </ul>
        </nav>
        
        <form action="" method="post">
        <div class="rowH">
            <div class="columnDPT">
                <pref>
                <h2>Dietary Preference</h2>
                    <input type="radio" id="standard" name="diet" value="1" required><label>Standard</label>
                    <input type="radio" id="vegitarian" name="diet" value="2"><label>Vegitarian</label>
                    <input type="radio" id="vegan" name="diet" value="3"><label>Vegan</label>
                </pref>
            </div>
        </div>
         <!--   
        <div class="rowDP">
            <h2 style="margin-left: 20px;">Dislikes</h2>
            <div class="columnDP">
                <div class = "choices">
                <legend>Carbohydrates</legend>
                    <label><input type="checkbox" name="carb" value="none" checked> None</label><br/>
                    <label><input type="checkbox" name="carb" value="rice" > Rice</label><br/>
                    <label><input type="checkbox" name="carb" value="potatoes"> Potatoes</label><br/>
                    <label><input type="checkbox" name="carb" value="bread"> Bread</label><br/>
                    <label><input type="checkbox" name="carb" value="pasta"> Pasta</label><br/>
                    <label><input type="checkbox" name="carb" value="oats" > Oats</label><br/>
                    <label><input type="checkbox" name="carb" value="sweetPotatoes"> Sweet Potatoes</label><br/>
                    <label><input type="checkbox" name="carb" value="bagel"> Bagel</label><br/>
                    <label><input type="checkbox" name="carb" value="lettuce"> Lettuce</label><br/>
                </div>
            </div>
            <div class="columnDP">
                 <div class = "choices">
                <legend>Protein</legend>
                    <label><input type="checkbox" name="protein" value="none" checked> None</label><br/>
                    <label><input type="checkbox" name="protein" value="chickenBreast" > Chicken breast</label><br/>
                    <label><input type="checkbox" name="protein" value="chickenThigh"> Chicken thigh</label><br/>
		    <label><input type="checkbox" name="protein" value="tofu"> Tofu</label><br/>
                    <label><input type="checkbox" name="protein" value="leanGroundTurkey"> Lean Ground turkey</label><br/>
                    <label><input type="checkbox" name="protein" value="Salmon"> Salmon </label><br/>
                    <label><input type="checkbox" name="protein" value="tilapia" > Tilapia</label><br/>
                    <label><input type="checkbox" name="protein" value="eggWhites"> Egg whites </label><br/>
                    <label><input type="checkbox" name="protein" value="wholeEggs"> Whole eggs</label><br/>
                    <label><input type="checkbox" name="protein" value="serloinSteak"> Serloin Steak </label><br/>
		    <label><input type="checkbox" name="protein" value="greekYogurt"> Greek Yogurt </label><br/>
                </div>
            </div>
            <div class="columnDP">
                <div class = "choices">
                <legend>Fat</legend>
                    <label><input type="checkbox" name="fat" value="none" checked> None</label><br/>
                    <label><input type="checkbox" name="fat" value="peanuts" > Peanuts</label><br/>
                    <label><input type="checkbox" name="fat" value="cashews"> Cashews </label><br/>
                    <label><input type="checkbox" name="fat" value="almonds"> Almonds </label><br/>
                    <label><input type="checkbox" name="fat" value="mozCheese"> Mozz Cheese</label><br/>
                    <label><input type="checkbox" name="fat" value="avacados"> Avacados </label><br/>
                    <label><input type="checkbox" name="fat" value="creamCheese"> Cream Cheese</label><br/>
                </div>
            </div>
        </div>
	-->
        <input type = "submit" name="next" value="Next">
        </form>
    </body>
</html>