<?php
session_start();
if (isset($_POST['next'])){
    
    foreach($_POST as $key => $value){
        $_SESSION['info'][$key]=$value;
    }
    
    $keys=array_keys($_SESSION['info']);
        
    if(in_array('submit',$keys)){
        unset($_SESSION['info']['submit']);
    }
       
    header("Location: mealplanP2.php");
    //print_r($_SESSION['info']);
}
?>
<!DOCTYPE html>
<html>
    <head>  
        <meta charset="utf-8">
        <title>Meal Plan Generator</title>
        <link rel="stylesheet" href="mpStyleSheet.css">
    </head>
    <body>
        <div class = "logo">
            <img src = "http://localhost/mealplan/mplogo.jpg">
        </div>
        
        <nav>
        <ul>
            <li><a href = "mealplanP1.php">Calculator</a></li>
            <li><a href = "mpInfo.html">How it works</a></li>
        </ul>
        </nav>
        <form action="" method="post">
        <div class="rowH">
        <div class="columnH">
                <h2>Height (in)</h2>
                <input type="number" id="height" name="height" required>
               
            </div>
            <div class="columnHR">
                <h2>Gender</h2>
                <div class="gender">
                    <input type="radio" id="female" name="gender" value="1" required>
                    <label for="female">Female</label>
                    <input type="radio" id="male" name="gender" value="2">
                    <label for="male">Male</label>
                </div>
            </div>    
        </div>
        
        <div class="rowH">
        <div class="columnH">
            
                <h2>Weight (lb)</h2>
                <input type="number" id="weight" name="weight" required>
    
            </div>
        <div class="columnHR">
            
            <h2>Activity Level</h2>
            <select id="diet" name="activityLevel" required>
            <option value="1"> Sedentary </option>
            <option value="2"> Lightly Active </option>
            <option value="3"> Moderately Active </option>
            <option value="4"> Very Active </option>
            <option value="5"> Extremly Active </option>
            </select>
            
        </div>    
        </div>
        
        <div class="rowH">
            
            <div class="columnH">
                <h2>Age</h2>
                <input type="number" id="age" name="age" required>
            </div>
            
            <div class="columnHR">
                
                <goal>
                <h2>Goal</h2>
                    <label><input type="radio" id="bulk" name="goal" value="3" required>Bulk</label>
                    <label><input type="radio" id="maintain" name="goal" value="2">Maintain</label>
                    <label> <input type="radio" id="cut" name="goal" value="1">Cut</label>
                </goal>
                
            </div>    
        </div>
        <input type="submit" name="next" value="Next">
    </form>
    </body>
</html>