<?php
session_start();

if(isset($_SESSION['info'])){
    extract($_SESSION['info']);
    //echo $fname;
    $conn = mysqli_connect('localhost','root','','mealplan_db');
    
    $sql= mysqli_query($conn,"INSERT INTO info (height,gender,weight,activityLevel,age,goal,diet)    
                       VALUES('$height','$gender','$weight','$activityLevel','$age','$goal','$diet')");

    if ($sql){
        unset($_SESSION['info']);
    }
    
}
	 $conn = mysqli_connect('localhost','root','','mealplan_db');

        if ($conn->connect_error) {
          die( "Failed to connect to MySQL: " . $conn->connect_error);
        }

        $heightInfo ="SELECT height FROM info ORDER BY id DESC LIMIT 1";
        $genderInfo ="SELECT gender FROM info ORDER BY id DESC LIMIT 1";
        $weightInfo ="SELECT weight FROM info ORDER BY id DESC LIMIT 1";
        $activityLevelInfo ="SELECT activityLevel FROM info ORDER BY id DESC LIMIT 1";
        $ageInfo ="SELECT age FROM info ORDER BY id DESC LIMIT 1";
        $goalInfo ="SELECT goal FROM info ORDER BY id DESC LIMIT 1";
        $dietInfo ="SELECT diet FROM info ORDER BY id DESC LIMIT 1";
       

        $resultHeight = $conn->query($heightInfo);
        $resultGender = $conn->query($genderInfo);
        $resultWeight = $conn->query($weightInfo);
        $resultActivityLevel = $conn->query($activityLevelInfo);
        $resultAge = $conn->query($ageInfo);
        $resultGoal = $conn->query($goalInfo);
        $resultDiet = $conn->query($dietInfo);

        $conn->close();

        $rowHeight = mysqli_fetch_all($resultHeight, MYSQLI_ASSOC);
        $rowGender = mysqli_fetch_all($resultGender, MYSQLI_ASSOC);
        $rowWeight = mysqli_fetch_all($resultWeight, MYSQLI_ASSOC);
        $rowActivityLevel = mysqli_fetch_all($resultActivityLevel, MYSQLI_ASSOC);
        $rowAge = mysqli_fetch_all($resultAge, MYSQLI_ASSOC);
        $rowGoal = mysqli_fetch_all($resultGoal, MYSQLI_ASSOC);
        $rowDiet = mysqli_fetch_all($resultDiet, MYSQLI_ASSOC);
       
        
        $height = array_column($rowHeight, "height");
        $gender = array_column($rowGender, "gender");
        $weight = array_column($rowWeight, "weight");
        $activityLevel = array_column($rowActivityLevel, "activityLevel");
        $age = array_column($rowAge, "age");
        $goal = array_column($rowGoal, "goal");
        $diet = array_column($rowDiet, "diet");
       
        
        echo '<script> var height = ' . json_encode($height) . '; </script>';
        echo '<script> var gender = ' . json_encode($gender) . '; </script>';
        echo '<script> var weight = ' . json_encode($weight) . '; </script>';
        echo '<script> var activityLevel = ' . json_encode($activityLevel) . '; </script>';
        echo '<script> var age = ' . json_encode($age) . '; </script>';
        echo '<script> var goal = ' . json_encode($goal) . '; </script>';
        echo '<script> var diet = ' . json_encode($diet) . '; </script>';
    
?>

<!DOCTYPE html>
<html>
    <head>  
        <meta charset="utf-8">
        <title>Meal Plan Generator</title>
        <link rel="stylesheet" href="mpStyleSheet.css">
        
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.min.js"></script>
<script> 
            
        var tdee;
        var bmr;
/*
Carbs: 4 calories per gram
40% of 2,000 calories = 800 calories of carbs per day
Total grams of carbs allowed per day = 800/4 = 200 grams
Proteins: 4 calories per gram
30% of 2,000 calories = 600 calories of protein per day
Total grams of protein allowed per day = 600/4 = 150 grams
Fats: 9 calories per gram
30% of 2,000 calories = 600 calories of protein per day
Total grams of fat allowed per day = 600/9 = 67 grams
*/

	var dStr;
	var protOpt;
	var carbOpt;
	var fatOpt;

	var perfCarb;
	var perfFat;
	var perfProt;

function start(){
    calcCalories();
    calcWeeklyLoss();
    calcMacros();
}
function getAL(){
    if (activityLevel==1){
       return 1.2;
    }
    else if (activityLevel==2){
        return 1.375;
    }
     else if (activityLevel==3){
        return 1.55;
    }
     else if (activityLevel==4){
        return 1.725;
    }
     else if (activityLevel==5){
        return 1.9;
    }
}
            
function getGoal(){
    if (goal==1){
        return 0.80;
    }
    else if(goal==2){
        return 1;
    }
    else if (goal==3){
        return 1.20;
        
    }
}

function calcCalories(){
    var kg = weight / 2.2046;
    height = height * 2.54;
    activityLevel= getAL();
    goal=getGoal();
    //if gender is 1 aka female
    //BMR = (10 × weight [kg]) + (6.25 × height [cm]) – (5 × age [years]) – 161
    if (gender==1){
        bmr = (10 * kg)+(6.25 * height) - (5 * age) - 161;
        tdee = bmr * activityLevel;
        calories = tdee * goal;
        document.getElementById("totalcalories").innerText = "Total Calories " + Math.round(calories);
    }
    //if gender is 2 aka male
    //BMR = (10 × weight [kg]) + (6.25 × height [cm]) – (5 × age [years]) + 5
    else{
        bmr = (10 * kg)+(6.25 * height) - (5 * age) + 5;
        tdee = bmr * activityLevel;
        calories = tdee * goal;

        document.getElementById("totalcalories").innerText = "Total Calories " + Math.round(calories);
    } 
}

function calcMacros(){
   if (goal==0.80){
        carb = (calories * .3) / 4;
	protein = weight;
       	//protein = (calories * .4) / 4;
    	fat = (calories * .3) / 9;
    }
    else if(goal==1){
        carb = (calories * .33) / 4;
	protein = weight;
       	//protein = (calories * .32) / 4;
    	fat = (calories * .33) / 9;;
    }
    else if (goal==1.2){
       carb = (calories * .36) / 4;
	protein = weight;
       	//protein = (calories * .28) / 4;
    	fat = (calories * .36) / 9;
        
    }
   
    var macroTable = document.getElementById("macroTable");
    macroTable.rows[1].cells[0].innerText = Math.round(carb)+"g";
    macroTable.rows[1].cells[1].innerText = Math.round(protein)+"g";
    macroTable.rows[1].cells[2].innerText = Math.round(fat)+"g";
}

function calcWeeklyLoss(){
    
    var deficit = calories - tdee;
    /*One lb of body fat contains about 3,500 calories. For a person to lose 1 lb of fat in a week,
    they would need a deficit of 3,500 calories, or 500 calories per day, */
    var weeklydef = deficit * 7;
    weeklyLoss = weeklydef / 3500 ;
 if(goal==1.2){
    document.getElementById("weeklyLoss").innerText = "+" + weeklyLoss.toFixed(2) + " lb weekly";
}
else{
    document.getElementById("weeklyLoss").innerText = weeklyLoss.toFixed(2) + " lb weekly";
}

}

function dietstr(){
	if(diet==1){
		return "Standard";
	}
	else if(diet==2){
		return "Vegitarian";
	}
	else if(diet==3){
		return "Vegan";
	}

}
            
function generateMeals(){
	//window.alert(prefCarb +" "+ prefProt +" "+ prefFat);
	var carbM=carb;
	var proteinM = protein;
	var fatM=fat;
	var caloriesM=calories;
	var generated = false;

	

	//servingsize, calories, carb, prot, fat, name, unit of measurment

	//carbs
	var rice= [135,160,35,3,0,"Long Grain White Rice","grams"];
      	var potatoes = [1,22,5,0,0.6,"Potatoes","oz"];
      	var bread = [1,70,13,2,.8,"White Bread","slices"];
      	var pasta = [0.5,50,10.5,1.8,0.2,"Pasta","oz"];
	var oats = [0.5,54,9.6,0.9,1.9,"Oats","oz"];
	var sweetPotatoes = [10,11,1.7,0.1,0.4,"Sweet Potatoes","grams"];
	var bagel =[10,28,5.6,0.9,0.2,"Bagels","grams"];
	var tortilla = [1,55,11,1,0.8,"6 inch Tortillas","tortillas"];

	//protein
	var chikenBreast = [1,30,0,5.8,0.6,"Chicken Breast","oz"];
      	var chickenThigh = [1,32,0,5.5,1.1,"Chicken Thigh","oz"];
      	var tofu = [1,13,0.4,1.4,0.7,"Tofu","oz"];
	var LeanGroundTurkey = [1,42,0,5.2,2,"Lean Ground Turkey","oz"];
	var shrimp = [1,20,0,4.5,0,"Shrimp","oz"];
	var tilapia =[25,20,0,4,0.3,"Tilapia","grams"];
	var serlionSteak = [1,60,0,5.5,4,"Serloin Steak","oz"];
	var eggWhites =[30,16,0,3.3,0,"Egg Whites","grams"];

	//fat
	var peanuts = [2,11,0.4,0.5,1,"Peanuts","grams"];
      	var almondButter = [4,25,0.8,0.8,2.2,"Almond butter","grams"];
      	var almonds = [0.10,16,0.6,0.6,1.4,"Almonds","oz"];
	var mozz = [5,14,0.4,0.9,1.2,"Mozzarella Cheese","grams"];
	var cheddar = [5,20,0.1,1.2,1.7,"Cheddar Cheese","grams"];
	var avacado =[1,45,2,1,4,"Avacados","oz"];

	//multiDementional Array
      	var foodOptions = [rice,potatoes,bread,pasta,oats,sweetPotatoes,bagel,tortilla,chikenBreast,chickenThigh,tofu,LeanGroundTurkey,shrimp,tilapia,serlionSteak,eggWhites,peanuts,almondButter,almonds,cheddar,avacado,mozz];
	
	if(prefCarb && prefProt && prefFat == "none"){
	//standard
	if(diet==1){
		//chicken
		//servingsize,calories,carb,prot,fat
		var proteinMac=[1,30,0,5.8,0.6,"Chicken Breast","oz"];
		//rice
		var carbMac=[135,160,35,3,0,"Long Grain White Rice","grams"];
		//avacado
		var fatMac=[1,45,2,1,4,"Avacados","oz"];
	}
	//vegitarian
	else if(diet==2){
		//tofu
		var proteinMac=[1,13,0.4,1.4,0.7,"Tofu","oz"];
		//rice
		var carbMac=[135,160,35,3,0,"Long Grain White Rice","grams"];
		//avacado
		var fatMac=[1,45,2,1,4,"Avacados","oz"];
	}
	//vegan
	else if(diet==3){
		//tofu
		var proteinMac=[1,13,0.4,1.4,0.7,"Tofu","oz"];
		//rice
		var carbMac=[135,160,35,3,0,"Long Grain White Rice","grams"];
		//avacado
		var fatMac=[1,45,2,1,4,"Avacados","oz"];
	
	}
	}
  	else{
	for(let i=0 ; i<foodOptions.length; i++){
		if (prefCarb==foodOptions[i][5]){
			prefCarb=foodOptions[i];
		}
		if (prefProt==foodOptions[i][5]){
			prefProt=foodOptions[i];
		}
		if (prefFat==foodOptions[i][5]){
			prefFat=foodOptions[i];
		}
	}
		var proteinMac=prefProt;
		var carbMac=prefCarb;
		var fatMac=prefFat;
	}
	

        while(generated==false){
        
            for(var qp=0;proteinM>= 0;qp++){
				proteinM=proteinM-proteinMac[3];
			}
		
			for(var qc=0;carbM>= 0;qc++){
				carbM=carbM-carbMac[2];
			}
	
			for(var qf=0;fatM>= 0;qf++){
				fatM=fatM-fatMac[4];
			}
		
            //window.alert(proteinM+" "+carbM+" "+fatM);
		      var carbCal=qc*carbMac[1];
        	   var proteinCal=qp*proteinMac[1];
        	   var fatCal=qf*fatMac[1];
            
             //window.alert(proteinCal+" "+carbCal+" "+fatCal);

		caloriesM=caloriesM-(carbCal+proteinCal+fatCal);
            generated=true;  
                }
		var carbMeal=((carbMac[0]*qc)/4);
		var proteinMeal=((proteinMac[0]*qp)/4);
		var fatMeal=((fatMac[0]*qf)/4);

		var meal=proteinMeal+" "+ proteinMac[6]+" of "+proteinMac[5]+"\n"+ carbMeal+" "+ carbMac[6]+" of "+carbMac[5]+"\n"+ fatMeal+" " +fatMac[6]+" of "+fatMac[5];
                    
               
        return meal;
	
}
            

function generatePDF(){
   		var n = new Date();
               	var date = (n.getMonth() + 1)+"_"+ n.getDate() +"_"+ n.getFullYear();
 	 	meal=generateMeals();
		//window.alert(meal);
		dStr=dietstr();
               
                var doc = new jsPDF();
               doc.setFont("times-roman");
                doc.setFontSize(12);
                doc.text(180, 290, date)

                doc.setFontSize(14);
                doc.text(15, 10, "Calories: " + Math.round(calories));
                doc.setFontSize(12);
                doc.text(15, 15, "Macros: " +Math.round(protein) +"g of protein | "+ Math.round(carb) +"g of carb | " + Math.round(fat) + "g of fat");
                 
		doc.setFontSize(20);
		doc.text(15, 35, "Reccomended Dietary Options");

		doc.setFontSize(14);
		doc.text(15, 42, 'Diet Style: '+ dStr);
		
		doc.setFontSize(20);
		doc.text(15, 60, "Meals");

		doc.setFontSize(12);
		doc.text(15, 65, "Split into 4 meals through the day" );

		doc.setFontSize(14);
		doc.text(15, 71, meal );
		//doc.text(15, 74, "Best carb option: "+ carbOpt );
		//doc.text(15, 81, "Best fat option: "+ fatOpt );

		doc.setFontSize(20);
		doc.text(15, 100,"Tips");

		doc.setFontSize(14);
		doc.text(15, 110,"Use an app");
		doc.setFontSize(12);
		doc.text(25, 115,"Thanks to modern technology, counting calories no longer has to involve much actual counting. ");
		doc.text(25, 120,"Apps can calculate calories for you. You can also put foods together into meals, which is a huge");
		doc.text(25, 125,"time saver.");

		doc.setFontSize(14);
		doc.text(15, 135,"Don't Just Focus On Calories");
		doc.setFontSize(12);
		doc.text(25, 140,"Weight loss has a lot to do with calories, but other factors are also important. Use your app to ");
		doc.text(25, 145,"monitor your fiber intake, and consider tracking your water intake, too. Getting more of both of ");
		doc.text(25, 150,"these can make a big difference in how full you feel, even while eating the same number of calories.");

		doc.setFontSize(14);
		doc.text(15, 160,"Build Around A Few Core Meals");
		doc.setFontSize(12);
		doc.text(25, 165,"A more time-efficient approach is to structure your diet around a few essential meals that are easy ");
		doc.text(25, 170,"to track and prepare the same way every time. This helps remove the guesswork and cuts down on data ");
		doc.text(25, 175,"entry. No, this doesn't mean you have to, or should eat the same thing all the time. Far from it!");
 		doc.text(25, 180,"But having a basic lineup of meals with numbers and ingredients you know by heart makes everything");
		doc.text(25, 185,"easier.");

		doc.setFontSize(14);
		doc.text(15, 195,"Don't try to be too perfect");
		doc.setFontSize(12);
		doc.text(25, 200,"Healthy eating shouldn't be about depriving yourself. If having a slice or two of cheese at lunch");
		doc.text(25, 205,"helps you get through the day, do it")

		doc.setFontSize(14);
		doc.text(15, 215,"Get a food scale");
		doc.setFontSize(12);
		doc.text(25, 220,"Having a food scale allows for more accurate tracking. This can also make it easier than having to");
		doc.text(25, 225,"pull out your measuring cups")

		doc.setFontSize(20);
		doc.text(15, 245,"Remember!");
		doc.setFontSize(14);
		doc.text(25, 250,"Come back to the website once you have plateaued to find your new calories");
		doc.text(25, 255,"and macros needed");

		

		/*
                doc.setFontSize(22);
                doc.text(20, 40, 'Meal 1');
                doc.setFontSize(12);
                doc.text(20, 50, meal1);
                
                
                doc.setFontSize(22);
                doc.text(20, 60, 'Meal 2');
                doc.setFontSize(12);
                doc.text(20, 70, meal2);
                
                
                doc.setFontSize(22);
                doc.text(20, 80, 'Meal 3');
                doc.setFontSize(12);
                doc.text(20, 90, meal3);
                
                
                doc.setFontSize(22);
                doc.text(20, 100, 'Meal 4');
                doc.setFontSize(12);
                doc.text(20, 110, meal4);
                */
    
                
    
                doc.save("mealplan"+date+".pdf")
           
}
            
function randomize(){
        generatePDF();
                
}

function PreferenceChanged() {
    prefCarb = document.getElementsByName("carb");
    for(let i = 0; i < prefCarb.length; i++) {
       if(prefCarb[i].checked){
           prefCarb=prefCarb[i].value;
	}
    }
    prefProt = document.getElementsByName("protein");
    for(let i = 0; i < prefProt.length; i++) {
       if(prefProt[i].checked){
           prefProt=prefProt[i].value;
	}
    }
    prefFat = document.getElementsByName("fat");
    for(let i = 0; i < prefFat.length; i++) {
       if(prefFat[i].checked){
           prefFat=prefFat[i].value;
	}
    }
    //window.alert(prefCarb +" "+ prefProt +" "+ prefFat);
    generatePDF();
    
}


window.addEventListener("load",start,false);
    </script>
    </head>
    <body>
        <div class = "logo">
            <img src = "http://localhost/mealplan/mplogo.jpg">
        </div>
        
        <nav>
        <ul>
            <li><a href = "mealplanP1.php">Calculator</a></li>
            <li><a href = "#">How it works</a></li>
        </ul>
        </nav>
        <div class="columnRL">
            <div class="rowR">
               <h1 style="margin-top: 60px;">Results</h1>
                <table id="macroTable">
            <thead>
                <tr>
                    <th>Carb</th>
                    <th>Protein</th>
                    <th>Fat</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="carb">#</td>
                    <td class ="protein">#</td>
                    <td class ="fat">#</td>
                </tr>
            </tbody>
        </table>
            </div>
            <div class="rowR">
                <div class = "weeklyLoss" id="weeklyLoss">lb weekly weight loss</div>
                <div class = "totalcalories" id="totalcalories">Total Calories #</div>
            </div>
            <div class="rowR">
                <div class="columnRL">
                <input id ="randomize" class="randbutton" type="button" value="Generate" onClick="PreferenceChanged()">
                </div>
                <div class="columnRR"> 
                      <p style = "font-size: 12pt; margin-top: 170px; text-align: right; margin-right: 20px;">Confused? Here is <a href="mpInfo.html" style="color:black;">how it works</a></p>
                </div>
            </div>
                
        </div>
        <div class="columnRR">
        
	 <h2 style="margin-left:20px;margin-bottom:0px; margin-top: 30px;">Preferred Food</h2>
             <div class="columnDP">
                <div class = "choices">
                <legend>Carbohydrates</legend>
                    <label><input type="radio" name="carb" value="none" checked> None</label><br/>
                    <label><input type="radio" name="carb" value="Long Grain White Rice" > Rice</label><br/>
                    <label><input type="radio" name="carb" value="Potatoes" > Potatoes</label><br/>
                    <label><input type="radio" name="carb" value="White Bread" > Bread</label><br/>
                    <label><input type="radio" name="carb" value="Pasta" > Pasta</label><br/>
                    <label><input type="radio" name="carb" value="Oats" > Oats</label><br/>
                    <label><input type="radio" name="carb" value="Sweet Potatoes" > Sweet Potatoes</label><br/>
                    <label><input type="radio" name="carb" value="Bagels" > Bagel</label><br/>
		     <label><input type="radio" name="carb" value="6 inch Tortillas"> Tortilla</label><br/>
                </div>
            </div>
            <div class="columnDP">
                 <div class = "choices">
                <legend>Protein</legend>
                    <label><input type="radio" name="protein" value="none" checked> None</label><br/>
                    <label><input type="radio" name="protein" value="Chicken Breast" > Chicken breast</label><br/>
                    <label><input type="radio" name="protein" value="Chicken Thigh" > Chicken thigh</label><br/>
		    <label><input type="radio" name="protein" value="Tofu" > Tofu</label><br/>
                    <label><input type="radio" name="protein" value="Lean Ground Turkey"> Lean Ground turkey</label><br/>
                    <label><input type="radio" name="protein" value="Shrimp" > Shrimp </label><br/>
                    <label><input type="radio" name="protein" value="Tilapia" > Tilapia</label><br/>
                    <label><input type="radio" name="protein" value="Egg Whites" > Egg whites </label><br/>
                    <label><input type="radio" name="protein" value="Serloin Steak" > Serloin Steak </label><br/>
                </div>
            </div>
            <div class="columnDP">
                <div class = "choices">
                <legend>Fat</legend>
                    <label><input type="radio" name="fat" value="none" checked > None</label><br/>
                    <label><input type="radio" name="fat" value="Peanuts" > Peanuts</label><br/>
                    <label><input type="radio" name="fat" value="Almond butter" > Almond butter </label><br/>
                    <label><input type="radio" name="fat" value="Almonds" > Almonds </label><br/>
                    <label><input type="radio" name="fat" value="Mozzarella Cheese" > Mozzarella Cheese</label><br/>
                    <label><input type="radio" name="fat" value="Avacados" > Avacados </label><br/>
                    <label><input type="radio" name="fat" value="Cheddar Cheese" > Cheddar Cheese</label><br/>
                </div>
            </div>
   
        </div>
        
    </body>
</html>